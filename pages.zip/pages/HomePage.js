const { expect } = require('@playwright/test');
const BasePage = require('./BasePage');

class HomePage extends BasePage {
  constructor(page) {
    super(page);
    this.page = page;

    // Header
    this.logo = page.getByRole('img', { name: 'Abelini Logo' });
    this.searchBox = page.locator('#menu-search');

    // Newsletter
    this.newsletterName = page.getByPlaceholder(/Your Name \*/i);
    this.newsletterEmail = page.getByPlaceholder(/Your email \*/i);
    this.subscribeBtn = page.getByRole('button', {
      name: 'Subscribe',
      exact: true
    });
  }

  async verifyHomeLoaded() {
    await expect(this.logo).toBeVisible();
    await expect(this.logo).toHaveAttribute('src', /abelini/i);

    await this.logo.click();
    //await expect(this.page).toHaveURL('https://www.abelini.com/');
  }

  async fillNewsletter(name, email) {
    await this.newsletterName.fill(name);
    await this.newsletterEmail.fill(email);
  }

  async clickSubscribeBtn() {
    await this.subscribeBtn.click();
  }

  async loginToDevStore(email) {
  // Go to site
  await this.page.goto('https://abelini-de-5e4c9d5a438332d59249.o2.myshopify.dev/', {
    waitUntil: 'domcontentloaded'
  });

  // Open account/login page
  const accountBtn = this.page.locator('a[href*="/account"], a:has-text("Account"), a:has-text("Login")');
  if (await accountBtn.first().isVisible()) {
    await accountBtn.first().click();
  }

  // Wait for email field
  const emailField = this.page.locator('#customer-authentication-web-email');
  await emailField.waitFor({ state: 'visible', timeout: 20000 });

  // Enter email
  await emailField.fill(email);

  // Continue / Send login code
  const continueButton = this.page.locator(
    'button[aria-label="Continue with Shop"]'
  );
  await continueButton.first().click();

  // Wait for OTP / verification screen
  await this.page.waitForSelector(
    'input[name="code"], input[autocomplete="one-time-code"]',
    { timeout: 60000 }
  );

  console.log("OTP screen opened - enter code manually or handle via email API.");
}

}


module.exports = HomePage;

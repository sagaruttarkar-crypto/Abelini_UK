const { expect } = require('@playwright/test');

class ProductPageMetaTitle {
  constructor(page) {
    this.page = page;

    this.productTitle = page.getByRole('heading', { level: 1 });

    this.testedCombinations = new Set();

    // Shape options
    this.shapeOptions = () =>
      this.page.locator('button').filter({
        hasText: /Round|Princess|Oval|Pear|Emerald|Cushion|Marquise|Heart|Asscher|Radiant/i,
      });

    // Stone options
    this.stoneOptions = () =>
      this.page.locator('button').filter({
        hasText: /Diamond|Ruby|Emerald|Blue Sapphire|Moissanite|Black Diamond|Lab Grown Diamond/i,
      });

    // Metal options
    this.metalOptions = () =>
      this.page.locator('div.flex.items-center.gap-\\[10px\\].pt-\\[5px\\] > button');
  }

  async waitForPageReady() {
    await this.page.waitForLoadState('domcontentloaded');
    await this.productTitle.waitFor({ state: 'visible' });
  }

  async getProductTitle() {
    const text = await this.productTitle.textContent();
    return text?.replace(/\s+/g, ' ').trim();
  }

  extractMetalFromTitle(title) {
    const t = title.toLowerCase();

    if (t.includes('white gold')) return 'White Gold';
    if (t.includes('yellow gold')) return 'Yellow Gold';
    if (t.includes('rose gold')) return 'Rose Gold';
    if (t.includes('platinum')) return 'Platinum';

    return 'Unknown';
  }

  async selectOption(locator) {
    try {
      if (!(await locator.isVisible().catch(() => false))) return null;

      await locator.scrollIntoViewIfNeeded();

      const optionText = await locator.textContent();
      const oldTitle = await this.getProductTitle();

      await locator.click();

      // Wait until title changes
      try {
        await expect(this.productTitle).not.toHaveText(oldTitle, {
          timeout: 4000,
        });
      } catch {
        await this.page.waitForTimeout(500);
      }

      return optionText?.trim();
    } catch {
      return null;
    }
  }

  async testAllCombinations() {
    await this.waitForPageReady();

    const shapes = this.shapeOptions();
    const stones = this.stoneOptions();
    const metals = this.metalOptions();

    const shapeCount = await shapes.count();
    const stoneCount = await stones.count();
    const metalCount = await metals.count();

    console.log("Shapes:", shapeCount);
    console.log("Stones:", stoneCount);
    console.log("Metals:", metalCount);
    console.log("================================");

    for (let s = 0; s < Math.max(shapeCount, 1); s++) {
      let shape = 'default';

      if (shapeCount > 0) {
        shape = await this.selectOption(shapes.nth(s));
        if (!shape) continue;
      }

      for (let st = 0; st < Math.max(stoneCount, 1); st++) {
        let stone = 'default';

        if (stoneCount > 0) {
          stone = await this.selectOption(stones.nth(st));
          if (!stone) continue;
        }

        for (let m = 0; m < Math.max(metalCount, 1); m++) {
          let metalBtnText = 'default';

          if (metalCount > 0) {
            metalBtnText = await this.selectOption(metals.nth(m));
            if (!metalBtnText) continue;
          }

          const title = await this.getProductTitle();
          const detectedMetal = this.extractMetalFromTitle(title);

          const comboKey = `${shape}-${stone}-${detectedMetal}`.toLowerCase();

          if (this.testedCombinations.has(comboKey)) continue;
          this.testedCombinations.add(comboKey);

          console.log(`Combination: ${comboKey}`);
          console.log(`Product Title: ${title}`);
          console.log("--------------------------------");
        }
      }
    }

    console.log(
      "Total unique combinations tested:",
      this.testedCombinations.size
    );
  }
}

module.exports = ProductPageMetaTitle;
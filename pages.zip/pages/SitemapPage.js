class SitemapPage {
  constructor(page) {
    this.page = page;
  }

  async navigateToSitemap() {
    await this.page.goto('https://abelini-de-5e4c9d5a438332d59249.o2.myshopify.dev/sitemap.xml');
  }
  


  async getSitemapLinks() {
    const urls = await this.page.evaluate(() => {
      const locs = Array.from(document.querySelectorAll('loc'));
      return locs.map(loc => loc.textContent);
    });
    return urls;
  }

  async validateUrlStatus(url) {
    const response = await this.page.request.get(url);
    return response.status();
  }
}

module.exports = SitemapPage;   

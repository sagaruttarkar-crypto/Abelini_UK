const { expect } = require('@playwright/test');
const BasePage = require('./BasePage');

class BlogPage extends BasePage {

  constructor(page, request) {
    super(page, request);

    // ✅ Only define locator here
    this.breadcrumbTitle = page
      .locator('.breadcrumb')
      .getByText('Blog',{ exact: true });
  }

  async validateBreadcrumb() {
    // ✅ Assertion should be here
    await expect(this.breadcrumbTitle).toBeVisible();
  }

}

module.exports = BlogPage;

const { expect } = require('@playwright/test');
const categoryData = require('../configs/test-data/categoryDescriptions');

class CategoryPage {
  constructor(page) {
    this.page = page;

    // CATEGORY LIST
    this.engagementCategories = [
      'classic-solitaire',
      'halo-rings',
      'side-stone-shoulder-set-rings',
      'three-stone',
      'cluster-engagement-rings',
      'illusion-set-rings',
      'toi-et-moi',
      'couples',
      'trilogy-rings',
      'twisted-engagement-ring',
      'gemstone-engagement-ring',
      'diamond-band',
      'unique-engagement-rings',
      'unusual-engagement-rings',
      'antique-engagement-rings',
      'vintage-engagement-rings',
      'minimalist-engagement-rings'
    ];

    this.breadcrumb = page.locator('.breadcrumb');
    this.productLinks = page.locator("a[href*='/product/']");
    this.productTitles = page.locator('h3');
    this.productPrices = page.locator("text=/£\\d+/");
    this.trustpilotBanner = page.locator('.collection-banner').first();
  }

  // ==============================
  // NAVIGATION
  // ==============================

  async navigateToEngagementCategory(slug) {
    await this.page.goto(`/engagement-rings/${slug}`, {
      waitUntil: 'domcontentloaded'
    });

    await this.productLinks.first().waitFor({ timeout: 20000 });
  }

  // ==============================
  // METAL FUNCTIONS (FIXED)
  // ==============================

async openMetalDropdown() {
  const metalBtn = this.page.locator('button', { hasText: 'Metal' });

  if (!(await metalBtn.isVisible().catch(() => false))) {
    console.log("Metal dropdown not available in this category");
    return false;
  }

  await metalBtn.click();

  const metalOptions = this.page.locator('div[data-type="metal"]');

  try {
    await metalOptions.first().waitFor({
      state: 'visible',
      timeout: 10000
    });
  } catch {
    console.log("No metal options found");
    return false;
  }

  return true;
}

async selectAllMetalsSequentially() {
  const hasDropdown = await this.openMetalDropdown();
  if (!hasDropdown) return;

  const metalOptions = this.page.locator('div[data-type="metal"]');
  const count = await metalOptions.count();

  console.log(`Total metals found: ${count}`);

  const metalNames = [];

  for (let i = 0; i < count; i++) {
    const name = await metalOptions.nth(i).getAttribute('data-name');
    metalNames.push(name);
  }

  console.log("Metals in this category:");
  metalNames.forEach(name => console.log(`- ${name}`));
}

  async collectProductLinks(metalName) {
    const count = await this.productLinks.count();
    console.log(`Products under ${metalName}: ${count}`);
  }

  // ==============================
  // TITLE
  // ==============================

  formatCategoryName(slug) {
    return slug
      .replace(/-/g, ' ')
      .replace(/\b\w/g, char => char.toUpperCase());
  }

  async validateTitleFromSlug(slug) {
    const formattedName = this.formatCategoryName(slug);
    const actualTitle = await this.page.title();
    await expect.soft(actualTitle).toContain(formattedName);
  }

  // ==============================
  // BREADCRUMB
  // ==============================

  async validateBreadcrumbFromSlug(slug) {
    const formattedName = this.formatCategoryName(slug);
    await expect.soft(this.breadcrumb).toContainText('Engagement Rings');
    await expect.soft(this.breadcrumb).toContainText(formattedName);
  }

  // ==============================
  // DESCRIPTION
  // ==============================

  async validateCategoryDescriptionFromSlug(slug) {
    const expectedText = categoryData[slug]?.description;
    if (!expectedText) return;

    const descriptionLocator = this.page.locator('p').first();

    if (!(await descriptionLocator.isVisible().catch(() => false))) {
      console.log(`No description for ${slug}`);
      return;
    }

    const actualText = await descriptionLocator.innerText();

    const normalize = text => text.replace(/\s+/g, ' ').trim();
    expect(normalize(actualText)).toBe(normalize(expectedText));

    console.log(`Description validated for ${slug}`);
  }

  // ==============================
  // PRODUCT VALIDATION
  // ==============================

  async validateAllProducts() {
    const count = await this.productLinks.count();
    expect(count).toBeGreaterThan(0);

    for (let i = 0; i < count; i++) {
      const title = await this.productTitles.nth(i).innerText();
      const href = await this.productLinks.nth(i).getAttribute('href');

      expect(title).toBeTruthy();
      expect(href).toContain('/product/');
    }
  }

  // ==============================
  // MASTER METHOD
  // ==============================

  async validateAllEngagementCategories() {
    for (const slug of this.engagementCategories) {
      console.log(`\nChecking category: ${slug}`);

      await this.navigateToEngagementCategory(slug);

      await this.selectAllMetalsSequentially();
    }
  }
}

module.exports = CategoryPage;
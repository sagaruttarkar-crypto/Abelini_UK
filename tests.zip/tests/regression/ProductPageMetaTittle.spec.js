const { test } = require('@playwright/test');
const ProductPageMetaTittle = require('../../pages/ProductPageMetaTittle');

test.setTimeout(10 * 60 * 1000); // 10 minutes

test('PDP variant Engagement Ring  combinations - Stylish 4 Prong Ring', async ({ page }) => {
  const productPage = new ProductPageMetaTittle(page);

  // Use full URL or ensure baseURL is set in Playwright config
  await page.goto('product/stylish-4-prong-setting-round-shape-classic-solitaire-ring-rinw9451');

  await productPage.testAllCombinations();
});

test.skip('PDP variant Wedding Ring - Oval 7 Diamond', async ({ page }) => {
  const productPage = new ProductPageMetaTittle(page);

  await page.goto('product/prong-setting-oval-shape-7-diamond-ring-rinw8970-lbg');

  await productPage.testAllCombinations();
});
test('PDP variant Diamond  Ring - Oval 7 Diamond', async ({ page }) => {
  const productPage = new ProductPageMetaTittle(page);

  await page.goto('product/pave-setting-crossover-knot-style-diamond-half-eternity-wedding-band-rinw5088');

  await productPage.testAllCombinations();
});
test('PDP variant Earring  Ring - Earring ', async ({ page }) => {
  const productPage = new ProductPageMetaTittle(page);

  await page.goto('product/channel-setting-round-diamond-earrings-ernw5222');

  await productPage.testAllCombinations();
});

test('PDP variant Bracelet  Ring ', async ({ page }) => {
  const productPage = new ProductPageMetaTittle(page);

  await page.goto('product/semi-bezel-set-round-brilliant-cut-line-tennis-diamond-bracelet-brc1015');

  await productPage.testAllCombinations();
});
test('PDP variant Necklace  ', async ({ page }) => {
  const productPage = new ProductPageMetaTittle(page);

  await page.goto('product/plain-gold-aquarius-zodiack-sign-pendant-pndw1500');

  await productPage.testAllCombinations();
});



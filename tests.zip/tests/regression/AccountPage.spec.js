const { test, expect } = require('@playwright/test');
const { AccountPage } = require('../../pages/AccountPage');

test.describe('Account Page Tests', () => {

  test('Account page loads with logged-in session', async ({ page, request }) => {
    const account = new AccountPage(page, request);

    await account.navigateWithNetworkIdle('/account');
    await account.verifyURL(/account/);
  });

  test('View Order History', async ({ page, request }) => {
    const account = new AccountPage(page, request);

    await account.navigateWithNetworkIdle('/account');
    await account.openOrderHistory();
    await account.verifyURL(/orders/);

    // Using BasePage table utility
    const orderId = await account.getTableCell(0, 0);
    console.log('First Order ID:', orderId);
  });

  test('Add New Address', async ({ page, request }) => {
    const account = new AccountPage(page, request);

    await account.navigateWithNetworkIdle('/account');
    await account.openAddressBook();
    await account.addNewAddress();

    await account.verifyURL(/address-list/);
  });

  test('Edit Address', async ({ page, request }) => {
    const account = new AccountPage(page, request);

    await account.navigateWithNetworkIdle('/account/address-list');
    await account.editAddress();
  });

  test('View Wishlist', async ({ page, request }) => {
    const account = new AccountPage(page, request);

    await account.navigateWithNetworkIdle('/account');
    await account.openWishlist();
    await account.verifyURL(/wishlist/);

    const items = await account.getWishlistProducts();
    console.log('Wishlist Products:', items);
  });

  test('Newsletter Subscription Page', async ({ page, request }) => {
    const account = new AccountPage(page, request);

    await account.navigateWithNetworkIdle('/account');
    await account.openNewsletter();
    await account.verifyURL(/newsletter/);
  });

});
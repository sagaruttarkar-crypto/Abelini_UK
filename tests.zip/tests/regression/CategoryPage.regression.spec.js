const { test } = require('@playwright/test');
const CategoryPage = require('../../pages/CategoryPage');
const categories = require('../../configs/test-data/categoryDescriptions');
test.only('Validate All Engagement Categories Sequentially', async ({ page }) => {

  test.setTimeout(180000); // 3 minutes

  const category = new CategoryPage(page);

  await category.validateAllEngagementCategories();

});

test('Validate All Wedding Rings Categories Sequentially', async ({ page }) => {

  test.setTimeout(180000); // 3 minutes

  const category = new CategoryPage(page);

  await category.validateAllWeddingEternityRingsCategories();

});
test('Validate All Diamond Rings Categories Sequentially', async ({ page }) => {

  test.setTimeout(180000); // 3 minutes

  const category = new CategoryPage(page);

  await category.validateAllDiamondRingsCategories();

});
test('Validate All Earrings Categories Sequentially', async ({ page }) => {

  test.setTimeout(180000); // 3 minutes

  const category = new CategoryPage(page);

  await category.validateAllEarringsCategories();

});
test('Validate All Necklaces Categories Sequentially', async ({ page }) => {

  test.setTimeout(180000); // 3 minutes

  const category = new CategoryPage(page);

  await category.validateAllNecklacesCategories();

});
test('Validate All Bracelets Categories Sequentially', async ({ page }) => {

  test.setTimeout(180000); // 3 minutes

  const category = new CategoryPage(page);

  await category.validateAllBraceletsCategories();

});

test('Validate Metals in Category', async ({ page }) => {
  test.setTimeout(180000);

  const category = new CategoryPage(page);

  await category.navigateToEngagementCategory('classic-solitaire');

  await category.selectAllMetalsSequentially();
});
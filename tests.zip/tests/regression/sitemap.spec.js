  const { test, expect } = require('@playwright/test');
  const xml2js = require('xml2js');

  // Config
  const SITEMAP_URL = 'https://abelini-de-5e4c9d5a438332d59249.o2.myshopify.dev/sitemap-image.xml';
  const BATCH_SIZE = 5;          // Number of URLs processed in parallel
  const RETRIES = 2;             // Retry failed requests
  const DELAY_MS = 200;          // Delay between requests in a batch

  test('Validate product pages and images with retries and throttling', async ({ request }) => {
    const brokenUrls = [];

    console.log(`Fetching sitemap: ${SITEMAP_URL}`);
    const response = await request.get(SITEMAP_URL);
    expect(response.ok()).toBeTruthy();

    const xml = await response.text();
    const parser = new xml2js.Parser();
    const result = await parser.parseStringPromise(xml);

    if (!result.urlset || !result.urlset.url) throw new Error('Invalid sitemap format');

    const urls = result.urlset.url;
    console.log(`Total URLs in sitemap: ${urls.length}`);

    // Function to check a single URL with retries
    async function checkUrl(url, attempt = 1) {
      try {
        const resp = await request.get(url, { failOnStatusCode: false });
        if (!resp.ok()) {
          if (attempt <= RETRIES) {
            console.log(`Retrying ${url} (attempt ${attempt})`);
            await new Promise(res => setTimeout(res, DELAY_MS));
            return await checkUrl(url, attempt + 1);
          }
          brokenUrls.push(`${url} -> ${resp.status()}`);
        }
      } catch (err) {
        if (attempt <= RETRIES) {
          console.log(`Retrying ${url} due to error: ${err.message} (attempt ${attempt})`);
          await new Promise(res => setTimeout(res, DELAY_MS));
          return await checkUrl(url, attempt + 1);
        }
        brokenUrls.push(`${url} -> NETWORK ERROR (${err.message})`);
      }
    }

    // Process sitemap in batches
    for (let i = 0; i < urls.length; i += BATCH_SIZE) {
      const batch = urls.slice(i, i + BATCH_SIZE);

      await Promise.all(
        batch.map(async (entry) => {
          const pageUrl = entry.loc[0];
          await checkUrl(pageUrl); // Check product page

          // Check images
          if (entry['image:image']) {
            for (const img of entry['image:image']) {
              const imgUrl = img['image:loc'][0];
              await checkUrl(imgUrl);
            }
          }
        })
      );

      // Optional small delay between batches to avoid CDN throttling
      await new Promise(res => setTimeout(res, 500));
    }

    // Final report
    console.log('\n===== BROKEN URL/IMAGE REPORT =====\n');
    if (brokenUrls.length > 0) {
      brokenUrls.forEach(u => console.log(u));
    } else {
      console.log('All URLs and images are valid ✅');
    }

    expect(brokenUrls.length, `Broken URLs/images detected:\n${brokenUrls.join('\n')}`).toBe(0);
});

  test('dev - Validate all main and inner sitemap URLs', async ({ page }) => {
  const baseSitemap = 'https://abelini-de-5e4c9d5a438332d59249.o2.myshopify.dev/sitemap.xml/';
  const brokenUrls = [];
  console.log('\n===== PROD SITEMAP VALIDATION =====\n');
  // 1️⃣ Open Main Sitemap
  const mainResponse = await page.goto(baseSitemap, {
    waitUntil: 'domcontentloaded',
    timeout: 24000
  });
  expect(mainResponse.status()).toBeLessThan(400);
  const body = await page.content();
  const mainSitemaps = [...body.matchAll(/<loc>(.*?)<\/loc>/g)]
    .map(match => match[1]);
  console.log(`Total Main Sitemaps Found: ${mainSitemaps.length}\n`);
  // 2️⃣ Loop through each main sitemap
  for (const mainUrl of mainSitemaps) {
    await page.waitForTimeout(500); // 👈 prevent bot detection
    const response = await page.goto(mainUrl, {
      waitUntil: 'domcontentloaded',
      timeout: 60000
    });
    const status = response.status();
    console.log(`Main Sitemap: ${mainUrl}`);
    console.log(`Status Code: ${status}\n`);
    if (status >= 400) {
      brokenUrls.push(`${mainUrl} -> ${status}`);
      continue;
    }
    const innerBody = await page.content();
    const innerUrls = [...innerBody.matchAll(/<loc>(.*?)<\/loc>/g)]
      .map(match => match[1]);
    console.log(`Total Inner URLs: ${innerUrls.length}\n`);
    // 3️⃣ Validate inner URLs
    for (const innerUrl of innerUrls) {
      await page.waitForTimeout(300); // 👈 prevent rapid-fire blocking
      const innerResponse = await page.goto(innerUrl, {
        waitUntil: 'domcontentloaded',
        timeout: 60000
      });
      const innerStatus = innerResponse.status();
      console.log(`   ↳ ${innerUrl} ---> ${innerStatus}`);
      if (innerStatus >= 400) {
        brokenUrls.push(`${innerUrl} -> ${innerStatus}`);
      }
    }
    console.log('\n--------------------------------------\n');
  }
  // 4️⃣ Final Broken Report
  console.log('\n===== BROKEN URL REPORT =====\n');
  if (brokenUrls.length > 0) {
    brokenUrls.forEach(url => console.log(url));
  } else {
    console.log('No Broken URLs Found ✅');
  }
  // 5️⃣ Proper Assertion with detailed message
  expect(
    brokenUrls,
    `Broken URLs detected:\n${brokenUrls.join('\n')}`
  ).toHaveLength(0);
});

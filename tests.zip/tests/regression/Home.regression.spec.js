const { test, expect } = require('@playwright/test');
const HomePage = require('../../pages/HomePage');

test.describe('Regression -Sprin2 Logo & Newsletter Validation', () => {

  test('Verify Abelini logo is visible and clickable @regression', async ({ page }) => {

    const home = new HomePage(page);

    // Navigate to home
    await home.navigate('/');

    // Validate logo visible
    await home.verifyHomeLoaded();

    // Click logo
    await home.logo.click();


  });


  test.only('Verify Newsletter subscription functionality @regression', async ({ page }) => {

    const home = new HomePage(page);

    // Navigate to home
    await home.navigate('/');

    // Fill newsletter
    await home.fillNewsletter('Sagar', 'Test123@email.com');

    // Click Subscribe
    await home.clickSubscribeBtn();

  });
  

});

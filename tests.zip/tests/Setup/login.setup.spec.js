const { test, expect } = require('@playwright/test');

test('Shopify login and save session', async ({ page }) => {

  await page.goto('/');

  // Click Login
  await page.locator('p').filter({ hasText: 'Login' }).first().click();

  // Email field
  const emailInput = page.locator('#customer-authentication-web-email');
  await emailInput.waitFor({ state: 'visible' });
  await emailInput.fill('sagar.uttarkar@soulible.com');

  // Continue
  await page.locator('[data-testid="login-button"]').first().click();

  // Shopify popup
  const popupEmail = page.locator('#IdentityEmailForm-input');

  if (await popupEmail.isVisible({ timeout: 15000 })) {
    await popupEmail.fill('sagar.uttarkar@soulible.com');
    await page.getByRole('button', { name: /Continue/i }).click();
  }

  // CRITICAL STEP (most people miss this)
  // Wait until Shopify redirects back to store
  await page.waitForURL('**/account**', { timeout: 60000 });

  // Also wait until account UI loads
  await page.waitForLoadState('networkidle');

  // Verify logged in
  await expect(page).toHaveURL(/account/);

  // Save session AFTER login completes
  await page.context().storageState({ path: 'auth.json' });

  console.log('Session saved successfully');
});
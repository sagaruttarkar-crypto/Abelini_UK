const { test, expect } = require('@playwright/test');

test('Save Shopify Login Session', async ({ page }) => {
  await page.goto('/');

  // Check if already logged in
  await page.goto('/account');
  await page.waitForLoadState('domcontentloaded');

  if (page.url().includes('/account')) {
    console.log('Already logged in. Reusing session.');
    return;
  }

  console.log('Session expired. Performing login...');

  await page.goto('/');

  const loginButton = page.getByText('Login').first();

  await loginButton.waitFor({ state: 'visible', timeout: 20000 });
  await loginButton.click();

  await page.fill('input[type="email"]', 'sagar.uttarkar@soulible.com');

  await page.getByRole('button', { name: /continue/i }).click();

  console.log('Complete login from email');

  await page.pause();

  await page.waitForLoadState('networkidle');

  await page.goto('/account');

  await expect(page).toHaveURL(/account/);

  await page.context().storageState({
    path: 'auth.json'
  });

  console.log('Session saved successfully');
});